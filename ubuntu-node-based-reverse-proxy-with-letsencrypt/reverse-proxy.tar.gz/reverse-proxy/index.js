
// Include redbird reverse proxy server (turn on bunyan=true for logging)
const SHOW_LOG = process.env.SHOW_LOG || '';
const DISABLE_XFWD = process.env.DISABLE_XFWD || '';
const proxy = require('redbird')({port: 80, ssl: { port: 443 }, bunyan: SHOW_LOG != '' ? true : false, xfwd: DISABLE_XFWD != '' ? false : true});
const auth = require('http-auth');

// Container's host ip address
const HOST_IP = process.env.HOST_IP || '';

// === Routine: Register a domain to 'http://ip:port', by using letsencrypt certificates ===
const regDomainTarget = (objProxy, strDomain, strTargetIp, iTargetPort, flgUseHttps) => {

  // if the string of the target-ip equals "HOST_IP", then take the host-ip variable instead of using it
  const strValidatedTargetIp = strTargetIp == 'HOST_IP' ? HOST_IP : strTargetIp;

  if (flgUseHttps) {
    // https, use letsencrypt certificate
    objProxy.register(strDomain, 'http://'+strValidatedTargetIp+':'+iTargetPort.toString(), {
      ssl: {
        cert: '/etc/letsencrypt/live/'+strDomain+'/cert.pem',
        key: '/etc/letsencrypt/live/'+strDomain+'/privkey.pem'
      }
    });
  } else {
    // non-https, just register
    objProxy.register(strDomain, 'http://'+strValidatedTargetIp+':'+iTargetPort.toString(), {});
  }

  // Log
  console.log('Registered '+strDomain+' ==> '+strValidatedTargetIp+':'+iTargetPort.toString());
};

// ################################################################################################################

// === Register accepted [Domain ==> Target:Port] list ===
const fs = require('fs');
const arrProxyList = JSON.parse(fs.readFileSync('/root/proxy-list.json', 'utf8') || '[]');

// proxy-list.json example:
//  [
//    {domain:"mydomain.com", ssl:1, target_ip:"localhost", target_port:3000},
//    {domain:"example2.com", ssl:0, target_ip:"HOST_IP"  , target_port:8080}
//  ]

// iterate reverse-proxy list items
for (let iIndex = 0 ; iIndex < arrProxyList.length ; iIndex++) {
  let objProxyItem = arrProxyList[iIndex];
  // register the [Domain ==> Target:Port] item
  regDomainTarget(proxy, objProxyItem.domain, objProxyItem.target_ip, objProxyItem.target_port, objProxyItem.ssl==1 ? true : false);
}

// ################################################################################################################

// === Non registered domains action / Catch all ====

// Use these credentials only if you want HTTP auth credentils for the "catch all" action
const authUser = 'MyAuthUser';
const authPass = 'MyAuthPassword';
// Request credetials wrapper
const basicAuth = auth.basic({realm: "Password is required."}, (username, password, callback) => {
  callback(username === authUser && password === authPass);
});

// Catch all ==> Peform 404 (change it to your needs)
const USE_404_AUTH  = process.env.USE_404_AUTH || '';

if (USE_404_AUTH != '') {
  proxy.notFound(basicAuth.check((req, res) => {
    res.writeHead(404, {"Content-Type": "text/plain"});
    res.write("404 NOT FOUND\n");
    res.end();
  }));
} else {
  proxy.notFound((req, res) => {
    res.writeHead(404, {"Content-Type": "text/plain"});
    res.write("404 NOT FOUND\n");
    res.end();
  });
}

// ################################################################################################################
