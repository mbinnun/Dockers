// requires
const http = require('http');
const cloudcmd = require('cloudcmd');
const app = require('express')();
const io = require('socket.io')();
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const { v4: uuidv4 } = require('uuid');
// server and socket
const server = http.createServer(app);
const socket = io.listen(server, {path: `/socket.io`});

// cloudcmd
const config = {name: 'cloudcmd'};
const filePicker = {data: {FilePicker: {key: 'key'}}};
const modules = {filePicker};
const {createConfigManager, configPath} = cloudcmd;
const configManager = createConfigManager({configPath});

// =============================================================================

// enable post and cookies
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());

// password protection
const protectionPassword = 'FileExp987';
const protectionLoginValue = uuidv4();
// check the request
app.use((req, res, next) => {
  const pw = req.body['pw'] || '';  // password from post
  const ipw = req.cookies['ipw'] || '';  // 'logged in' cookie
  if (ipw == protectionLoginValue) { // if having a cookie and the login value is correct ==> continue
    next();
  } else {
    if (pw == protectionPassword) { // if entered password and password is correct ==> save the 'logged in' cookie
      res.cookie('ipw', protectionLoginValue);
      // reload after saving the cookie
      res.set('Content-Type', 'text/html; charset=utf-8');
      res.end(`
        <!DOCTYPE html>
        <html lang="en">
          <head>
            <meta charset="utf-8" />
            <title>FileExplorer Login</title>
          </head>
          <body>
            Signing in, please wait ...
            <script>window.setTimeout(window.location.reload.bind(window.location), 10);</script>
          </body>
        </html>
      `);
    } else {
      // ask for password
      res.set('Content-Type', 'text/html; charset=utf-8');
      res.end(`
        <!DOCTYPE html>
        <html lang="en">
          <head>
            <meta charset="utf-8" />
            <title>FileExplorer Login</title>
          </head>
          <body>
            <h1>FileExplorer Login</h1>
            <form method="POST" action="">
              Enter a password:<br />
              <input type="password" name="pw" value="" /><br />
              <input type="submit" value="Login" />
            </form>
          </body>
        </html>
      `);
    }
  }
});

// ==================================================================================

// use cloudcmd
const prefix = '/';
app.use(prefix, cloudcmd({
  socket, // used by Config, Edit (optional) and Console (required)
  config, // config data (optional)
  modules, // optional
  configManager, // optional
}));

// listen
server.listen(8081, '0.0.0.0');
