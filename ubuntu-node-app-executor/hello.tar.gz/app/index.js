console.log('Hello from App.'+'\n'+'Change this APP to your needs.');

const ENV_VAR = process.env.ENV_VAR || '';
console.log('ENV_VAR = '+ENV_VAR);

const http = require('http');
http.createServer( (request, response) => {
   response.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'});
   response.end('Hello from HttpServer.'+'<br/>'+'Change this to your needs.'+'<br/><br/>'+'ENV_VAR = '+ENV_VAR);
} ).listen(3000);
console.log('\n'+'Hello from HttpServer.'+'Now listening on port 3000.');
